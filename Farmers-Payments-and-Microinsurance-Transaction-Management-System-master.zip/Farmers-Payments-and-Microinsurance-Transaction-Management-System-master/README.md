# MishMash Hackathon

Project designed and Developed By Team **bro_code**.

Kiran - https://github.com/Apollo9999

Fahad Hassan - https://github.com/FahadHassan2499

Nihal Pandey - https://github.com/nihalpandey4

Nishkarsh Tripathi - https://github.com/A-lone-Contributer

## Farmers-Payments-and-Microinsurance-Transaction-Management-System

Farming is the major occupation in India since ages. Jai Kisan Motive of the Indian government has given the commitment to doubling farmers’ income by 2022 and the objective of this project aims to boost the income of farmers and enhance their standard of living and purchasing power the following below are features to consider.

Making the life of farmers easier, better and secure one transaction at a time!

A Decentralized Payments and Microinsurance Transaction Management System for Farmers.

Agriculture is the most important sector of the Indian Economy. The Indian agriculture sector accounts for 18 percent of India's gross domestic product and provides employment to 50% of the countries workforce. Yet every day we can see that the farmers are in various kinds of troubles and are facing a lot of issues economically as well as they are not able to tap the schemes or tech facilities available which can help solve a lot of issues.

In order to address these issues we have come with Payeasy, Blockchain is the Tamperproof technology which uses a decentralized payment cum micro-insurance transaction system on a decentralized blockchain public ledger along with a responsive UI which can help farmers make secure payments which are recorded in public ledgers and can act as a proof in case any fraud or mismanagement related to payments that happen against him. Similarly, we have introduced a facility to purchase micro-insurance and add the details of the same to the ledger so that they get the freedom to decide the amount, type, validity of the coverage at a very flexible price and also help them get claims instantly in case of calamities as there is almost no documentation needed for the same.

Further, the whole platform is decoupled and various developers can use the dev-friendly APIs in order to integrate into their apps and make secure payments using the paysaan network. You need not worry about security, as we have Multi-Factor Authentication from the user side to process the transactions and various Hashing and Encryption algorithms are placed at multiple levels to keep you safe and enjoy transacting and progressing. Why Payeasy Easier to use a phone number and password than a public key and private key for transactions? It provides simple interface to use the platform implemented multi-factor authentication to ensure secure and developer-friendly APIs for further implementation in other programs. Supports micro-insurance for cheap, fast and reliable insurance coverage for various needs Fraud prevention by blockchain based public ledger.

### Tech Stack Used:

Spring Boot, Python, Angular, Twilio Messaging API, MySQL and Microsoft Azure Web Interface.

**Twilio's Programmable SMS API** helps you add robust messaging capabilities to our applications. Using this REST API, we can send and receive SMS messages, track the delivery of sent messages, and retrieve and modify message history.

**Spring Boot** is an open source Java-based framework used to create a micro Service. It is developed by the Pivotal Team and is used to build stand-alone and production-ready spring applications.
