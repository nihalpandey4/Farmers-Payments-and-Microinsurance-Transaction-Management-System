export class User {
  phoneNo: number;
  password: string;
  name: string;
  address: string;
  publicKey: string;
  privateKey: string;
}
