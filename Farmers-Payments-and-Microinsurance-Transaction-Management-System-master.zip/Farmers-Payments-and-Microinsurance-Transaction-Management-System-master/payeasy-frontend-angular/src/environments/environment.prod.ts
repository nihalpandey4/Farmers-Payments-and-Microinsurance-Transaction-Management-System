export const environment = {
  production: true,
  spring: 'https://paysaan-spring-boot.azurewebsites.net',
  python: 'https://paysaan-python-server.azurewebsites.net',
  pythonClient: 'https://paysaan-python-client.azurewebsites.net'
};
