package com.sudo_win.paysaan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaysaanApplicationTests {

    @Test
    void contextLoads() {
    }

}
