package com.sudo_win.paysaan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaysaanApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaysaanApplication.class, args);
    }

}
